from django.apps import AppConfig


class Try1AppConfig(AppConfig):
    name = 'try1app'
